﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImageScanner
{
    public class WindowMessageHook : IMessageFilter
    {
        Form _window;
        bool _usingFilter;

        public WindowMessageHook(Form window)
        {
            _window = window;
        }

        public bool PreFilterMessage(ref Message m)
        {
            //if (FilterMessageCallback != null)
            //{
                //bool handled = false;
                return FilterMessageFunc(ref m);
                //return handled;
            //}

            //return false;
        }

        //public IntPtr WindowHandle { get { return _windowHandle; } }

        public bool UseFilter
        {
            get
            {
                return _usingFilter;
            }
            set
            {
                if (!_usingFilter && value == true)
                {
                    _window.BeginInvoke((Action)(() => Application.AddMessageFilter(this)));
                    //Application.AddMessageFilter(this);
                    _usingFilter = true;
                }

                if (_usingFilter && value == false)
                {
                    _window.BeginInvoke((Action)(() => Application.RemoveMessageFilter(this)));
                    //Application.RemoveMessageFilter(this);
                    _usingFilter = false;
                }
            }
        }

        public FilterMessage FilterMessageFunc { get; set; }        

    }

    public delegate bool FilterMessage(ref Message m);
}
