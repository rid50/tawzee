using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace ImageScanner
{
    partial class Form1
    {
        void runScanForm()
        {
            if (backgroundWorkerScanForm.IsBusy)
                return;

            backgroundWorkerScanForm.RunWorkerAsync();
        }

        private void backgroundWorkerScanForm_DoWork(object sender, DoWorkEventArgs e)
        {
            _twainForm = new TwainForm(this);
        }
    }
}
