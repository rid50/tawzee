//#define SHOW_TREAHD_IDS

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Security.Principal;
using System.Configuration;
using System.IO;

using TwainLib;
using System.DirectoryServices.AccountManagement;
using System.Threading;
using GdiPlusLib;
using PdfSharp.Drawing;
using PdfSharp.Pdf;
using System.Reflection;
//using ImageScanner.PTServices;

namespace ImageScanner
{
    //public partial class Form1 : Form, IMessageFilter
    public partial class Form1 : Form
    {
        private BackgroundWorker backgroundWorkerProgressBar;
        private BackgroundWorker backgroundWorkerAuthentication;
        private BackgroundWorker backgroundWorkerDB;
        //private BackgroundWorker backgroundWorkerScanForm;

        private UserProfile _user = null;
        private bool _isImageSourceSelected = false;

        //delegate void InitOrSelectSourceComplete(Object sender, TwainOperationCompleteEventArgs args);

        //TwainForm _twainForm = null;
        Twain _twain = null;
        bool _isDocumentScan = true;

        System.Collections.Concurrent.BlockingCollection<Tuple<bool, Action>> _queue = new System.Collections.Concurrent.BlockingCollection<Tuple<bool, Action>>();
        internal System.Collections.Concurrent.BlockingCollection<Tuple<bool, Action>> GetQueue
        {
            get
            {
                return _queue;
            }
        }

        SynchronizationContext _context;
        internal SynchronizationContext GetSynchronizationContext
        {
            get
            {
                return _context;
            }
        }

        //~Form1()
        //{
        //    Dispose();
        //}

        public Form1()
        {
            InitializeComponent();

            var t = new Thread(() =>
            {
                while (true)
                {
                    var item = _queue.Take();
#if SHOW_TREAHD_IDS
                    string currThread = System.Threading.Thread.CurrentThread.ManagedThreadId.ToString();
                    GetSynchronizationContext.Send(
                        delegate
                        {
                            toolStripStatusLabelError.Text += currThread + " thread queue | ";
                        }, null);
#endif
                    //this.BeginInvoke((Action)(() =>
                    //{
                    //    toolStripStatusLabelError.Text += System.Threading.Thread.CurrentThread.ManagedThreadId.ToString() + " action | ";
                    //}), null);

                    if (!item.Item1) break;
                    item.Item2();
                }
            });
            t.Start();

            backgroundWorkerProgressBar = new BackgroundWorker();
            backgroundWorkerProgressBar.WorkerSupportsCancellation = true;
            backgroundWorkerProgressBar.WorkerReportsProgress = true;
            backgroundWorkerProgressBar.DoWork += new DoWorkEventHandler(backgroundWorkerProgressBar_DoWork);
            backgroundWorkerProgressBar.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerProgressBar_RunWorkerCompleted);
            backgroundWorkerProgressBar.ProgressChanged += new ProgressChangedEventHandler(backgroundWorkerProgressBar_ProgressChanged);

            backgroundWorkerAuthentication = new BackgroundWorker();
            backgroundWorkerAuthentication.DoWork += new DoWorkEventHandler(backgroundWorkerAuthentication_DoWork);
            backgroundWorkerAuthentication.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerAuthentication_RunWorkerCompleted);

            backgroundWorkerDB = new BackgroundWorker();
            backgroundWorkerDB.DoWork += new DoWorkEventHandler(backgroundWorkerDB_DoWork);
            backgroundWorkerDB.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorkerDB_RunWorkerCompleted);

            //backgroundWorkerScanForm = new BackgroundWorker();
            //backgroundWorkerScanForm.DoWork += new DoWorkEventHandler(backgroundWorkerScanForm_DoWork);

            _context = SynchronizationContext.Current;


            StatusBar bar = new StatusBar();
            bar.Visible = true;

#if SHOW_TREAHD_IDS
            toolStripStatusLabelError.Text += System.Threading.Thread.CurrentThread.ManagedThreadId.ToString() + " mainform | ";
#endif
            //Thread t = new Thread(new ThreadStart(() => _twainForm = new TwainForm(this)));
            //t.Start();

            //Task<TwainForm> t = Task.Factory.StartNew(() => _twainForm = new TwainForm(this));

            //Task<TwainForm> t = new Task<TwainForm>(() => _twainForm = new TwainForm(this));
            //t.Start();

            //runScanForm();

            //_twainForm = new TwainForm(this);
            _twain = new Twain(new WindowMessageHook(this), this);

            _twain.TwainOperationComplete += delegate(Object sender, TwainOperationCompleteEventArgs args)
            {
                if (args.Error)
                {
                    _twain.CloseSrc();
                    this.BeginInvoke((Action)(() => { 
                        toolStripStatusLabelError.Text = "Error while scan is in process";
                        this.Cursor = Cursors.Default;
                        enableButtons(true);
                        stopProgressBar();
                    }), null);
                }
            };

            _twain.TransferImage += delegate(Object sender, TransferImageEventArgs args)
            {
                if (args.Error)
                {
                    //_twain.CloseSrc();
                    this.BeginInvoke((Action)(() =>
                    {
                        toolStripStatusLabelError.Text = "Error while scan is in process";
                    }), null);
                }
                else if (args.Image != null && args.Image.Count != 0)
                {
                    MemoryStream ms = null;

                    for (int i = 0; i < args.Image.Count; i++)
                    {
                        IntPtr imgPtr = (IntPtr)args.Image[i];
                        IntPtr bmpPtr = Gdip.GlobalLock(imgPtr);
                        IntPtr pixPtr = BitmapUtils.GetPixelInfo(bmpPtr);

                        Guid clsid;
                        //String strFileName = @"c:\" + Environment.MachineName + i.ToString() + DateTime.Now.Millisecond + ".jpg";
                        String inFileName = "temp.jpg";
                        if (Gdip.GetCodecClsid(inFileName, out clsid))
                        {
                            IntPtr imgPtr2 = IntPtr.Zero;
                            Gdip.GdipCreateBitmapFromGdiDib(bmpPtr, pixPtr, ref imgPtr2);
                            Gdip.GdipSaveImageToFile(imgPtr2, inFileName, ref clsid, IntPtr.Zero);

                            Gdip.GdipDisposeImage(imgPtr2);
                            Gdip.GlobalFree(imgPtr);
                            imgPtr = IntPtr.Zero;
                            imgPtr2 = IntPtr.Zero;

                            //break;

                            ms = new MemoryStream();
                            Form1.DbHelper db = new Form1.DbHelper();

                            if (!_isDocumentScan)
                            {
                                //MethodInfo mi = typeof(Bitmap).GetMethod("FromGDIplus", BindingFlags.Static | BindingFlags.NonPublic);
                                //Bitmap bmp = (Bitmap)mi.Invoke(null, new object[] { imgPtr2 });

                                Bitmap bmpOrig = new Bitmap(inFileName);
                                //Bitmap bmp = new Bitmap(bmpOrig.Width, bmpOrig.Height, System.Drawing.Imaging.PixelFormat.Format32bppArgb);
                                Bitmap bmp = bmpOrig.Clone(new Rectangle(0, 0, bmpOrig.Width, bmpOrig.Height), System.Drawing.Imaging.PixelFormat.Format8bppIndexed);
                                //Color backColor = bmp.GetPixel(10, 10);

                                //bmp.MakeTransparent(Color.White);
                                bmp.MakeTransparent(Color.Transparent);

                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbfaff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fdff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#faffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbfaff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f9feff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fafefd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fefefe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbfffe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f9fdfe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fcfd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfdff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f5fafd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f9fdff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fafeff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f7fcff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fafafc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f2fdf7"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfdfc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f9f9fa"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f5f7f3"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbf9fe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fafbff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcfcfc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f4f9fc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcfdff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f6fafb"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f6fbfe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f5fefe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f6feff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fcff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfffe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcfefd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f9fffd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbfcff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8f9fd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fdf6"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f3f8fb"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f7fbfc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbfffa"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fefe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8f9fb"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fffe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fafbfd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f7ffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fefbfb"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f3fbfd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fefeff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fefc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fafff9"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f5f7ff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#faf8fd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f7f7fe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfeff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fffafc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f6fafd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f5f8ff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f6f9fe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f7f6fe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f8fbff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f6fffc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#f9fefa"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcfcfa"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fef8ff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfdf6"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fffbf8"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfbff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcfaff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfdfd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fcfef7"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#eaeef0"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fdfbfe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#edf1f2"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fbfbfd"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffffff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffffff"));
                                
                                
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#ebeff2"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#f1fffa"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#eafff6"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#e7fcf3"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#e5f9f7"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#ecfffe"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#d8fdf5"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#c8fff8"));
                                ////bmp.MakeTransparent(ColorTranslator.FromHtml("#d2fff4"));


                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fff0fe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffe0fc"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffdffb"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffe7fe"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#ffedff"));
                                //bmp.MakeTransparent(ColorTranslator.FromHtml("#fff4f9"));
                                
                                //bmp.Save("temp_converted_to_16bit.png", System.Drawing.Imaging.ImageFormat.Png);
                                bmp.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                                byte[] buff = ms.ToArray();
                                byte[] buff2 = null;

                                //Gdip.GdipDisposeImage(imgPtr2);
                                //Gdip.GlobalFree(imgPtr);
                                //imgPtr = IntPtr.Zero;
                                //imgPtr2 = IntPtr.Zero;

                                //Image img = null;
                                try
                                {
                                    db.SaveAttachment(this.User, ref buff, ref buff2, args.Width, args.Height, args.Resolution);
                                    Image img = Image.FromStream(ms);
                                    this.Invoke((Action<Image>)((im) =>
                                    {
                                        pictureBox1.Image = im;
                                    }), img);
                                }
                                catch (Exception ex)
                                {
                                    this.Invoke((Action<String>)((mes) =>
                                    {
                                        toolStripStatusLabelError.Text = ex.Message;
                                    }), null);
                                }
                                finally
                                {
                                    //img.Dispose();

                                    if (ms != null)
                                    {
                                        ms.Close();
                                        ms = null;
                                    }

                                    bmpOrig.Dispose();
                                    bmp.Dispose();
                                }
                                //Image imgb = (Image)bmp2;
                                //imgb.Save("temp_transparent.gif", System.Drawing.Imaging.ImageFormat.Gif);  
                            }


                            if (!_isDocumentScan)
                                break;

                            //Gdip.GdipDisposeImage(imgPtr2);
                            //Gdip.GlobalFree(imgPtr);
                            //imgPtr = IntPtr.Zero;
                            //imgPtr2 = IntPtr.Zero;

                            XImage ximg = XImage.FromFile(inFileName);
                            PdfDocument doc = new PdfDocument();
                            PdfPage page = new PdfPage();
                            page.Width = ximg.PixelWidth;
                            page.Height = ximg.PixelHeight;
                            doc.Pages.Add(page);
                            XGraphics xgr = XGraphics.FromPdfPage(doc.Pages[0]);

                            xgr.DrawImage(ximg, 0, 0);

                            //ms = new MemoryStream();
                            doc.Save(ms, false);
                            byte[] buffer_pdf = ms.ToArray();

                            //var ms4 = new MemoryStream(buffer_pdf);
                            //PdfDocument doc4 = new PdfDocument();
                            //doc4 = PdfSharp.Pdf.IO.PdfReader.Open(ms4);
                            //doc4.Save("doc4.pdf");

                            //String outFileName = "temp.pdf";
                            //doc.Save(outFileName);
                            ximg.Dispose();
                            doc.Close();
                            ms.Close();
                            ms = null;

                            FileStream fs = new FileStream(inFileName, FileMode.Open, FileAccess.Read);
                            BinaryReader br = new BinaryReader(fs);
                            byte[] buffer = br.ReadBytes((int)fs.Length);

                            //fs.Close();
                            //fs = null;
                            //Image image = Image.FromFile(strFileName);
                            ms = new MemoryStream(buffer);
                            Image image = Image.FromStream(ms);
                            Image image2 = BitmapUtils.resizeImage(image, 480);

                            ms.Close();
                            ms = null;
                            ms = new MemoryStream();
                            image2.Save(ms, System.Drawing.Imaging.ImageFormat.Jpeg);
                            byte[] buffer2 = ms.ToArray();

                            //Form1.DbHelper db = new Form1.DbHelper();
                            try
                            {
                                db.SaveAttachment(this.User, ref buffer_pdf, ref buffer2);
                                //db.SaveAttachment(CheckAndGetUserProfile(), ref buffer_pdf, ref buffer2);
                                Image img = Image.FromStream(fs);

                                //Action<Image> myact = (im) =>
                                //{
                                //    pictureBox1.Image = im;
                                //    txtAttachmentTitle.Text = this.User.Title;
                                //    txtAttachmentUser.Text = this.User.DisplayName;
                                //    txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                                //};

                                //this.BeginInvoke(myact, img);

                                this.Invoke((Action<Image>)((im) =>
                                {
                                    pictureBox1.Image = im;
                                    txtAttachmentTitle.Text = this.User.Title;
                                    txtAttachmentUser.Text = this.User.DisplayName;
                                    txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");
                                }), img);

                                //Action<Image> imAction = (im) => SetImage(img);
/*
                                if (_mainForm.InvokeRequired)
                                    _mainForm.Invoke((Action<Image>)((im) => SetImage(img)));
                                //_mainForm.Invoke(new SetImageFunc(SetImage), img);
                                else
                                    SetImage(img);
*/
                                //_mainForm.pictureBox1.Image = img;
                                //_mainForm.txtAttachmentTitle.Text = _mainForm.User.Title;
                                //_mainForm.txtAttachmentUser.Text = _mainForm.User.DisplayName;
                                //_mainForm.txtAttachmentDate.Text = DateTime.Now.ToString("dd/MM/yyyy");

                                //pictureBox1.Image = image2;
                            }
                            catch (Exception ex)
                            {
                                this.Invoke((Action<Exception>)((mes) =>
                                {
                                    toolStripStatusLabelError.Text = mes.Message; 
                                }), ex);

/*
                                if (_mainForm.InvokeRequired)
                                    _mainForm.Invoke((Action)(() => SetStatusLabelError(ex.Message)));
                                //_mainForm.Invoke(new SetStatusLabelErrorFunc(SetStatusLabelError), ex.Message);
                                else
                                    SetStatusLabelError(ex.Message);
*/
                                //_mainForm.toolStripStatusLabelError.Text = ex.Message;
                            }
                            finally
                            {
                                if (fs != null)
                                    fs.Close();
                                if (ms != null)
                                    ms.Close();

                                if (image != null)
                                    image.Dispose();
                                if (image2 != null)
                                    image2.Dispose();

                                //File.Delete(inFileName);
                            }
                        }
                        else
                        {
                            //toolStripStatusLabelError.Text = "No codec found for the file: " + inFileName;
                            break;
                        }

                        //fs.Close();
                        //try
                        //{
                        //    //File.Delete(strFileName);
                        //}
                        //catch { }
                    }


/*
                    if (_mainForm.InvokeRequired)
                        _mainForm.Invoke((Action)(() => StopProgressBar()));
                    else
                        StopProgressBar();
*/
                    ////this.Enabled = true;
                    ////_mainForm.Activate();
                    //_mainForm.Cursor = Cursors.Default;
                    //_mainForm.enableButtons(true);
                    //_mainForm.stopProgressBar();
                }

                this.Invoke((Action)(() =>
                {
                    this.Cursor = Cursors.Default;
                    enableButtons(true);
                    stopProgressBar();
                }), null);
            };


            _twain.TwainInitOrSelectComplete += delegate(Object sender, TwainOperationCompleteEventArgs args)
            {
                if (args.Error)
                {
                    this.BeginInvoke((Action)(() =>
                    {
                        labelImageSource.ForeColor = Color.Red;
                        labelImageSource.Text = _twain.getInfo();
                    }), null);

                    _isImageSourceSelected = false;

                }
                else
                {
                    this.BeginInvoke((Action)(() =>
                    {
                        labelImageSource.ForeColor = Color.Green;
                        labelImageSource.Text = _twain.getInfo();
                        _isImageSourceSelected = true;
                        enableScan(true);
                    }), null);
                }
            };


            IntPtr handle = this.Handle;
            _queue.Add(Tuple.Create<bool, Action>(true, (() => _twain.InitLib(handle))));
            //_twain.InitLib(handle);


            //_twainForm.Visible = false;

//            tw = new Twain();
/*
            //short retCode = tw.Init(this.Handle);
            short retCode = _twain.Init(this.Handle);
            if (retCode != 0)
            {
                labelImageSource.ForeColor = Color.Red;
                labelImageSource.Text = _twain.getInfo();
            }
            else
            {
                labelImageSource.ForeColor = Color.Green;
                labelImageSource.Text = _twain.getInfo();

                _isImageSourceSelected = true;
            }
*/
        }

 
/*
        private String getAuthorizedPersonFDN()
        {
            int i = txtPersonId.Text.LastIndexOf("\\");
            if (i != -1)
                return txtPersonId.Text;
            else
            {
                if (txtDomain.Text.Length == 0)
                    return txtPersonId.Text;
                else
                    return txtDomain.Text + "\\" + txtPersonId.Text;
            }
        }
*/
        private void get_Click(object sender, EventArgs e)
        {
            //Action<IntPtr> meth = handle => _twain.InitLib(handle);
            //_queue.Add(Tuple.Create<bool, Action<IntPtr>>(true, meth));
            //IntPtr handle = this.Handle;
            //_queue.Add(Tuple.Create<bool, Action>(true, (() => _twain.InitLib(handle))));

            if (_isDocumentScan && txtCivilId.Text == "")
            {
                toolStripStatusLabelError.Text = "Enter an application number";
                return;
            }

#if !SHOW_TREAHD_IDS
            toolStripStatusLabelError.Text = "";
#endif

            _user.ApplicationNumber = txtCivilId.Text;
                        
            this.Cursor = Cursors.WaitCursor;
            enableButtons(false);
            clearControls();
            listBox.Items.Clear();

            List<object> args = new List<object>();
            args.Add("getAttachmentList");
            args.Add(_isDocumentScan);
            startProgressBar();
            startDbProcess(args);
            //backgroundWorkerDB_DoWork(null, null);
        }
/*
        public delegate bool AcquireImage();
        //public AcquireImage d;
        private void CallbackMethod(IAsyncResult ar) 
        {
            // Retrieve the delegate.
            AsyncResult result = (AsyncResult)ar;
            AcquireImage caller = (AcquireImage)result.AsyncDelegate;

            // Call EndInvoke to retrieve the results.
            bool returnValue = caller.EndInvoke(ar);
        }
*/
        private void scan_Click(object sender, EventArgs e)
        {
/*
            String inFileName = "temp.jpg";
            String outFileName = "temp.pdf";
            PdfSharp.Drawing.XImage ximg = PdfSharp.Drawing.XImage.FromFile(inFileName);

            PdfSharp.Pdf.PdfDocument doc = new PdfSharp.Pdf.PdfDocument();
            PdfSharp.Pdf.PdfPage page = new PdfSharp.Pdf.PdfPage();
            page.Width = ximg.PixelWidth;
            page.Height = ximg.PixelHeight;
            doc.Pages.Add(page);
            PdfSharp.Drawing.XGraphics xgr = PdfSharp.Drawing.XGraphics.FromPdfPage(doc.Pages[0]);

            xgr.DrawImage(ximg, 0, 0);
            doc.Save(outFileName);
            doc.Close();

            return;
*/

            if (_isDocumentScan && txtCivilId.Text == "")
            {
                toolStripStatusLabelError.Text = "Enter an application number";
                return;
            }

#if !SHOW_TREAHD_IDS
            toolStripStatusLabelError.Text = "";
#endif

            _user.ApplicationNumber = txtCivilId.Text;

            if (txtAttachmentTitle.Text == "")
                txtAttachmentTitle.Text = Properties.Resources.sketch;

            _user.Title = txtAttachmentTitle.Text;

            this.Cursor = Cursors.WaitCursor;
            enableButtons(false);
            clearControls();
            listBox.Items.Clear();

            Application.DoEvents();

            //AcquireImage d = new AcquireImage(_twainForm.Acquire);
            ////_twainForm.BeginInvoke(d);
            //d.BeginInvoke(new AsyncCallback(CallbackMethod), null);
            _queue.Add(Tuple.Create<bool, Action>(true, (() => _twain.AcquireImage(_isDocumentScan))));
            startProgressBar();
        }

        private void logon_Click(object sender, EventArgs e)
        {
#if !SHOW_TREAHD_IDS
            toolStripStatusLabelError.Text = "";
#endif
            txtCivilId.Enabled = false;
            enableButtons(false);

            startProgressBar();
            startAuthProcess(txtDomain.Text, txtPersonId.Text, txtPassword.Text);
            //backgroundWorkerAuthentication_DoWork(null, null);
            //System.Threading.Thread.Sleep(10000);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            WindowsIdentity windowsIdentity = WindowsIdentity.GetCurrent();
            int i = windowsIdentity.Name.LastIndexOf("\\");
            if (i != -1)
            {
                txtDomain.Text = windowsIdentity.Name.Substring(0, i);
                txtPersonId.Text = windowsIdentity.Name.Substring(i + 1);
                //txtPersonId.Text = "tamalallah";
                _user = new UserProfile();
                UserPrincipalEx principal = null;
                //_user.UserId = txtDomain.Text + "\\" + txtPersonId.Text;
                try
                {
                    PrincipalContext context = new PrincipalContext(ContextType.Domain);
                    principal = UserPrincipalEx.FindByIdentity(context, IdentityType.SamAccountName, txtPersonId.Text);
                    char[] ch = principal.ExtensionName.ToCharArray();
                    _user.DisplayName = principal.DisplayName;
                    _user.UserId = txtPersonId.Text;
                    //_user.DisplayName = principal.ExtensionName;
                }
                catch (Exception ex)
                {
                    toolStripStatusLabelError.Text = ex.Message;
                    _user.DisplayName = txtPersonId.Text;
                    enableButtons(false);
                    return;
                }

            }
            else
            {
                txtDomain.Text = String.Empty;
                txtPersonId.Text = windowsIdentity.Name;
            }

/*
            IdentityReferenceCollection coll = windowsIdentity.Groups;
            IEnumerator it = coll.GetEnumerator();
            while (it.MoveNext())
            {
                String str = ((IdentityReference)it.Current).Translate(typeof(NTAccount)).Value;
                int ii = 0;
            }

            WindowsPrincipal principal = new WindowsPrincipal(windowsIdentity);
            bool b = principal.IsInRole(ConfigurationManager.AppSettings["AuthorizationGroup"]);
*/

            txtPassword.Text = "******";

            txtCivilId.Enabled = false;

            enableButtons(false);
            clearControls();

            txtAttachmentTitle.ForeColor = Color.LightGray;
            txtAttachmentTitle.Text = Properties.Resources.sketch;
            this.txtAttachmentTitle.Leave += new System.EventHandler(this.txtAttachmentTitle_Leave);
            this.txtAttachmentTitle.Enter += new System.EventHandler(this.txtAttachmentTitle_Enter);

            this.ActiveControl = txtPersonId;
            this.AcceptButton = btnLogon;

#if DEBUG
//            txtPersonId.Text = "ri.russia";
//            txtPersonId.Text = "ri.davidenko";
//            txtPassword.Text = "";

//            txtCivilId.Text = "287062301977";
//            txtCivilId.Text = "282033000734";
//            txtCivilId.Text = "10";
//            txtCivilId.Text = "250031301609";
            
#endif

            String domainLocation = ConfigurationManager.AppSettings["DomainLocation"];
//            if (domainLocation.StartsWith(txtDomain.Text, StringComparison.InvariantCultureIgnoreCase) ||
//                domainLocation.Equals("rootDSE"))
            if (domainLocation.StartsWith(txtDomain.Text, StringComparison.InvariantCultureIgnoreCase))
            {
                btnLogon.PerformClick();
                btnLogon.Enabled = false;
            }

        }

        internal UserProfile User
        {
            get { return _user; }
        }

        private void txtPersonId_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogon;
        }

        private void txtPassword_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnLogon;
        }

        private void txtCivilId_Enter(object sender, EventArgs e)
        {
            this.AcceptButton = btnGet;
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            IntPtr handle = this.Handle;
            _queue.Add(Tuple.Create<bool, Action>(true, (() => _twain.SelectSource(handle))));
            //_twain.SelectSource(handle);


/*
            short retCode = _twainForm._tw.Select(_twainForm.Handle);
            //short retCode = tw.Select(this.Handle);
            if (retCode != 0)
            {
                labelImageSource.ForeColor = Color.Red;
                labelImageSource.Text = _twainForm._tw.getInfo();

                _twainForm._isImageSourceSelected = false;

            }
            else
            {
                labelImageSource.ForeColor = Color.Green;
                labelImageSource.Text = _twainForm._tw.getInfo();

                _twainForm._isImageSourceSelected = true;

                if (txtAttachmentTitle.Text.Length != 0)
                    enableScan(true);
            }
*/ 
        }

        private void txtAttachmentTitle_Leave(object sender, EventArgs e)
        {
            if (txtAttachmentTitle.Text.Length == 0)
            {
                txtAttachmentTitle.Text = Properties.Resources.sketch;
                txtAttachmentTitle.ForeColor = Color.LightGray;
            }
        }

        private void txtAttachmentTitle_Enter(object sender, EventArgs e)
        {
            if (txtAttachmentTitle.Text == Properties.Resources.sketch)
            {
                txtAttachmentTitle.Text = "";
                txtAttachmentTitle.ForeColor = Color.Black;
            }
        }

        private void txtPersonId_TextChanged(object sender, EventArgs e)
        {
            btnLogon.Enabled = true;
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            btnLogon.Enabled = true;
        }

        private void txtCivilId_TextChanged(object sender, EventArgs e)
        {
            //clearControls();
        }

        private void enableScan(bool flag) {
            if (flag && _authOk && _isImageSourceSelected)
                btnScan.Enabled = true;
            else
                btnScan.Enabled = false;
        }

        private void clearControls()
        {
            pictureBox1.Image = null;
            pictureBox1.Invalidate();
            txtAttachmentTitle.Text = "";
            txtAttachmentUser.Text = "";
            txtAttachmentDate.Text = "";
            //toolStripStatusLabelError.Text = "";
        }

        internal void enableButtons(bool flag)
        {
            enableScan(flag);
            btnGet.Enabled = flag;
            btnDelete.Enabled = flag;
            btnUpdateTitle.Enabled = flag;
        }

        private void listBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (((ListBox)sender).SelectedItem != null)
            {
                List<object> args = new List<object>();
                args.Add("getAttachment");
                var it = (KeyValuePair<int, string>)((ListBox)sender).SelectedItem;
                args.Add(it.Key);
                args.Add(_isDocumentScan);
                startProgressBar();
                startDbProcess(args);
            }
        }

        private void btnUpdateTitle_Click(object sender, EventArgs e)
        {
            if (txtAttachmentTitle.Text == "")
                return;
            else
            {
                List<object> args = new List<object>();
                args.Add("updateTitle");
                var it = (KeyValuePair<int, string>)listBox.SelectedItem;
                args.Add(it.Key);
                args.Add(txtAttachmentTitle.Text);
                startProgressBar();
                startDbProcess(args);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem != null)
            {
                toolStripStatusLabelError.Text = "";

                List<object> args = new List<object>();
                args.Add("deleteAttachment");
                var it = (KeyValuePair<int, string>)listBox.SelectedItem;
                args.Add(it.Key);
                args.Add(_isDocumentScan);
                startProgressBar();
                startDbProcess(args);
            }
        }

        private void rbDocument_CheckedChanged(object sender, EventArgs e)
        {
            label3.Visible = true;
            txtCivilId.Visible = true;
            _isDocumentScan = true;
        }

        private void rbSignature_CheckedChanged(object sender, EventArgs e)
        {
            label3.Visible = false;
            txtCivilId.Visible = false;
            _isDocumentScan = false;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (listBox.SelectedIndex != -1 && e.KeyCode == Keys.Delete)
            {
                btnDelete.PerformClick();
                e.Handled = true;
            }
        }
    }
}